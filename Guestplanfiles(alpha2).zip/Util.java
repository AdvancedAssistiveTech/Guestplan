public class Util {
	public void exit() {
		System.out.println(" Exiting in five seconds...");
		try {
			Thread.sleep(5000);
		}
		catch(Exception e) {
		}
		System.out.print("Terminated");
		System.exit(0);
	}
	public void Criticalexit() {
		System.out.println("\n\nUnexpected error. Exiting...");
		System.exit(1);
	}
	public void welcome() {
		System.out.println("Welcome to \n\n" + "                                                                                                                                                                       \r\n" + 
				"                                                                                                                                                                       \r\n" + 
				"        GGGGGGGGGGGGG                                                                tttt          PPPPPPPPPPPPPPPPP   lllllll                                         \r\n" + 
				"     GGG::::::::::::G                                                             ttt:::t          P::::::::::::::::P  l:::::l                                         \r\n" + 
				"   GG:::::::::::::::G                                                             t:::::t          P::::::PPPPPP:::::P l:::::l                                         \r\n" + 
				"  G:::::GGGGGGGG::::G                                                             t:::::t          PP:::::P     P:::::Pl:::::l                                         \r\n" + 
				" G:::::G       GGGGGGuuuuuu    uuuuuu      eeeeeeeeeeee        ssssssssss   ttttttt:::::ttttttt      P::::P     P:::::P l::::l   aaaaaaaaaaaaa  nnnn  nnnnnnnn         \r\n" + 
				"G:::::G              u::::u    u::::u    ee::::::::::::ee    ss::::::::::s  t:::::::::::::::::t      P::::P     P:::::P l::::l   a::::::::::::a n:::nn::::::::nn       \r\n" + 
				"G:::::G              u::::u    u::::u   e::::::eeeee:::::eess:::::::::::::s t:::::::::::::::::t      P::::PPPPPP:::::P  l::::l   aaaaaaaaa:::::an::::::::::::::nn      \r\n" + 
				"G:::::G    GGGGGGGGGGu::::u    u::::u  e::::::e     e:::::es::::::ssss:::::stttttt:::::::tttttt      P:::::::::::::PP   l::::l            a::::ann:::::::::::::::n     \r\n" + 
				"G:::::G    G::::::::Gu::::u    u::::u  e:::::::eeeee::::::e s:::::s  ssssss       t:::::t            P::::PPPPPPPPP     l::::l     aaaaaaa:::::a  n:::::nnnn:::::n     \r\n" + 
				"G:::::G    GGGGG::::Gu::::u    u::::u  e:::::::::::::::::e    s::::::s            t:::::t            P::::P             l::::l   aa::::::::::::a  n::::n    n::::n     \r\n" + 
				"G:::::G        G::::Gu::::u    u::::u  e::::::eeeeeeeeeee        s::::::s         t:::::t            P::::P             l::::l  a::::aaaa::::::a  n::::n    n::::n     \r\n" + 
				" G:::::G       G::::Gu:::::uuuu:::::u  e:::::::e           ssssss   s:::::s       t:::::t    tttttt  P::::P             l::::l a::::a    a:::::a  n::::n    n::::n     \r\n" + 
				"  G:::::GGGGGGGG::::Gu:::::::::::::::uue::::::::e          s:::::ssss::::::s      t::::::tttt:::::tPP::::::PP          l::::::la::::a    a:::::a  n::::n    n::::n     \r\n" + 
				"   GG:::::::::::::::G u:::::::::::::::u e::::::::eeeeeeee  s::::::::::::::s       tt::::::::::::::tP::::::::P          l::::::la:::::aaaa::::::a  n::::n    n::::n     \r\n" + 
				"     GGG::::::GGG:::G  uu::::::::uu:::u  ee:::::::::::::e   s:::::::::::ss          tt:::::::::::ttP::::::::P          l::::::l a::::::::::aa:::a n::::n    n::::n     \r\n" + 
				"        GGGGGG   GGGG    uuuuuuuu  uuuu    eeeeeeeeeeeeee    sssssssssss              ttttttttttt  PPPPPPPPPP          llllllll  aaaaaaaaaa  aaaa nnnnnn    nnnnnn " + "\n\n");
	}
}