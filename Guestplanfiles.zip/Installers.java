import java.io.*;
import java.util.*;

public class Installers {
	Util utility = new Util();
	
	Formatter fwrite = new Formatter();
	
	Scanner uin = new Scanner(System.in);
	Scanner reader = null;
	
	File f;
	public void C() {
		System.out.println("Beginning installation...\n\n");
		try {
			new File("C:/Guestplan").mkdir();
		}
		catch(Exception e) {
			System.out.println("Error creating directory C:/Guestplan. Please try again later");
			utility.exit();
		}
		System.out.println("Directory C:/Guestplan created successfully");
		try {
			new File("C:/Guestplan/main").mkdir();
		}
		catch(Exception e) {
			System.out.println("Error creating directory C:/Guestplan/main. Please try again later");
			utility.exit();
		}
		System.out.println("Directory C:/Guestplan/main created successfully");
		try {
			new File("C:/Guestplan/data").mkdir();
		}
		catch(Exception e) {
			System.out.println("Error creating directory C:/Guestplan/data. Please try again later");
			utility.exit();
		}
		System.out.println("Directory C:/Guestplan/data created successfully");
		try {
			new File("C:/Guestplan/main/ic.cf").mkdir();
		}
		catch(Exception e) {
			System.out.print("Error creating installation verification file. Please try again later");
			utility.exit();
		}
		System.out.println("Installation verification file created successfully");
		System.out.println("\nInstallation on C: drive successful");
	}
	public void D() {
		System.out.println("Beginning installation...\n\n");
		try {
			new File("D:/Guestplan").mkdir();
		}
		catch(Exception e) {
			System.out.println("Error creating directory D:/Guestplan. Please try again later");
			utility.exit();
		}
		System.out.println("Directory D:/Guestplan created successfully");
		try {
			new File("D:/Guestplan/main").mkdir();
		}
		catch(Exception e) {
			System.out.println("Error creating directory D:/Guestplan/main. Please try again later");
			utility.exit();
		}
		System.out.println("Directory D:/Guestplan/main created successfully");
		try {
			new File("D:/Guestplan/data").mkdir();
		}
		catch(Exception e) {
			System.out.println("Error creating directory D:/Guestplan/data. Please try again later");
			utility.exit();
		}
		System.out.println("Directory D:/Guestplan/data created successfully");
		try {
			fwrite = new Formatter("D:/Guestplan/main/ic.cf");
			fwrite.format("", "");
		}
		catch(Exception e) {
			System.out.print("Error creating installation verification file. Please try again later");
			utility.exit();
		}
		System.out.println("Installation verification file created successfully");
		System.out.println("\nInstallation on D: drive successful");
	}
	public void userData(){
		String username, password;
		f = new File("C:/Guestplan/main/ic.cf"); //ic.cf = installationcheck.criticalfile
		if(f.exists()) {
			try {
				fwrite = new Formatter("C:/Guestplan/main/lidat.txt"); //logindata.criticalfile
			}
			catch(Exception e) {
				utility.Criticalexit();
			}
		}
		else {
			f = new File("D:/Guestplan/main/ic.cf");
		}
		if(f.exists()) {
			try {
				fwrite = new Formatter("D:/Guestplan/main/lidat.cf"); //logindata.criticalfile
			}
			catch(Exception e) {
				utility.Criticalexit();
			}
		}
		System.out.print("Please confirm your user details. Note that these will be required upon login" + "\n\n" + "Username: ");
		username = uin.next();
		System.out.print("Password: ");
		password = uin.next();
		fwrite.format("%s %n %s", username, password);
	}
}
