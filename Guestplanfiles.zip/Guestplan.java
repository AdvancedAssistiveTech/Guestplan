import java.util.*;
import java.io.*;

public class Guestplan {
	public static void main(String args[]) {
		Util util = new Util();
		
		Installers inst = new Installers();
		
		String uinput, uname = null, pword = null;
		
		Scanner sc = new Scanner(System.in);
		Scanner fread = null;
		
		File f, f2 = new File("");
		
		Boolean cont; //control
		
		Scanner instprog = null; //installation progress
		
		int inststep = 0; //installation step
		
		Formatter fwrite = null;
		
		
		cont = false;
		f = new File("C:/Guestplan/main/ic.cf"); //ic.cf = installationcheck.criticalfile
		if(f.exists()) {
			f2 = new File("C:/Guestplan/main/ip.cf"); //ip.cf = installationprogress.criticalfile
			if(f2.exists()) {
				try {
					instprog = new Scanner(new File("C:/Guestplan/main/ip.cf"));
				}
				catch(Exception e) {
				}
				while(instprog.hasNext()) {
					inststep = instprog.nextInt();
				}
			}
		}
		else {
			f = new File("D:/Guestplan/main/ic.cf");
		}
		if(f.exists()) {
			f2 = new File("D:/Guestplan/main/ip.cf"); //ip.cf = installationprogress.criticalfile
			if(!f2.exists()) {
				cont = false;
			}
			else {
				try {
					instprog = new Scanner(new File("D:/Guestplan/main/ip.cf"));
				}
				catch(Exception e) {
				}
			}
		}
		if(inststep == 0) {
			while(!cont) {
				System.out.println("Installation has not been completed. Do so now (y,n)");
				uinput = sc.next();
				if(uinput.startsWith("y") || uinput.startsWith("Y")) {
					inststep = 1;
					cont = true;
				}
				else if(uinput.startsWith("n") || uinput.startsWith("N")) {
					System.out.println("The application is unable to run without critical files.");
					util.exit();
				}
				else {
					System.out.println("invalid input. Try again\n");
				}
			}
		}
		if(inststep == 1) {
			// The installer begins here
			cont = false;
			while(!cont) {
				System.out.print("Install on (C): or (D): drive: ");
				uinput = sc.next();
				if(uinput.startsWith("C") || uinput.startsWith("c")) {
					inst.C();
					try {
						fwrite = new Formatter("C:/Guestplan/main/ip.cf");
					}
					catch(Exception e) {
					}
					inststep = 2;
					fwrite.format("%o", inststep);
					cont = true;
				}
				else if(uinput.startsWith("D") || uinput.startsWith("d")) {
					inst.D();
					try {
						fwrite = new Formatter("D:/Guestplan/main/ip.cf");
					}
					catch(Exception e) {
					}
					inststep = 2;
					fwrite.format("%o", inststep);
					cont = true;
				}
				else {
					System.out.println("Invalid input. Try again");
				}
			}
			fwrite.close();
		}
		if(inststep == 2) {
			cont = false;
			while(!cont) {
				System.out.print("(C)ontinue setup, or (E)xit: ");
				uinput = sc.next();
				if(uinput.startsWith("c") || uinput.startsWith("C")) {
					inst.userData();
					cont = true;
				}
				else if(uinput.startsWith("e") || uinput.startsWith("E")) {
					util.exit();
					cont = true;
				}
				else {
					System.out.println("Invalid input. Please try again");
				}
			}
			inststep = 3;
			f = new File("C:/Guestplan/main/ic.cf");
			if(f.exists()) {
				try {
					fwrite = new Formatter("C:/Guestplan/main/ip.cf");
				}
				catch(Exception e) {
					util.Criticalexit();
				}
			}
			else {
				f = new File("D:/Guestplan/main/ic.cf");
				if(f.exists()) {
					try {
						fwrite = new Formatter("D:/Guestplan/main/ip.cf");
					}
					catch(Exception e) {
						util.Criticalexit();
					}
				}
			}
			fwrite.format("%o", inststep);
			fwrite.close();
		}
		util.welcome();
		f = new File("C:/Guestplan/main/lidat.cf");
		if(f.exists()) {
			try {
				fread = new Scanner(new File("C:/Guestplan/main/lidat.cf"));
			}
			catch(Exception e) {
			}
		}
		else {
			f = new File("D:/Guestplan/main/lidat.cf");
			if(f.exists()) {
				try {
					fread = new Scanner(new File("D:/Guestplan/main/lidat.cf"));
				}
				catch(Exception e) {
					
				}
			}
			else {
				System.out.println("Login data file not found. Recommend reinstallation");
				util.Criticalexit();
			}
		}
		while(fread.hasNext()) {
			uname = fread.next();
			pword = fread.next();
			break;
		}
		System.out.print("Please enter login details\n" + "Username: ");
		while(true) {
			uinput = sc.next();
			if(!uinput.equals(uname)) {
				System.out.print("Username incorrect. Please try again\nUsername: ");
			}
			else {
				break;
			}
		}
		System.out.print("Password: "); 
		while(true) {
			uinput = sc.next();
			if(!uinput.equals(pword)) {
				System.out.print("Password incorrect. Please try again\nPassword: ");
			}
			else {
				break;
			}
		}
		
		sc.close();
	}
}